a = ("Hi","Bye")
b = ("VL","Meet you","Soon")
print(tuple(zip(a,b)))
