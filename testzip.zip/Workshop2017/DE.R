##############################################
##### This script shows how to identify ######
#####  expressed genes in RNA-Seq data  ######
##############################################

##### Read gene annotations ######
annotations=read.delim("gene_description.txt",as.is=TRUE,quote="",sep="\t")

##### Read counts per gene ######

# each sample group has three replicates
# sample names look like:
#   GroupName.Number
# For example:  
#   YLf.1, YLf.2, YLf.3 for YLf (young leaf)
counts_filename='counts.txt'
counts=read.delim(counts_filename,as.is=TRUE,
                  sep='\t',row.names="gene")


# read sample information
# each row is a sample
sample_info=read.delim("samples.txt",as.is=TRUE,sep="\t",
                       header=TRUE,comment.char = '#',
                       row.names = "sample_name")


# check that sample_info row names match 
# counts column names
row.names(sample_info)==names(counts)

# load EdgeR library 
library(edgeR)

# make a Differential Gene Expression list - contains
# counts matrix and samples data frame with metadata
# about the experiment
sample_groups=sample_info$group
big_DGEList=DGEList(counts=counts,group=sample_groups,
                  remove.zeros = TRUE)

##### Exploratory Data Analysis ######

# Use a barplot to visualize counts per library
# define colors for samples
colors=c("turquoise3","lawngreen","limegreen","darkgoldenrod1",
         "green4","cadetblue","hotpink1","darkorange1",
         "blue1","mediumpurple1","coral","brown4")
sample_colors=rep(colors,each=3)
names(sample_colors)=rownames(big_DGEList$samples)
libsizes=big_DGEList$samples$lib.size/10**6
names(libsizes)=rownames(big_DGEList$samples)
barplot(libsizes,col=sample_colors,las=2)


# use multidimensional scaling (a form of clustering)
# to compare samples, check that replicates are similar
plotMDS(big_DGEList,col=sample_colors,main="MDS plot")

##### Find differentially expressed genes ######

# As an example, compare early to late seeds

# pick groups to compare
group1_name='ESD'
group2_name='LSD'

# Create a new DGEList that contains 
# early and late seed samples only
group1_indexes=grep(group1_name,names(counts)) 
group2_indexes=grep(group2_name,names(counts))
indexes=c(group1_indexes,group2_indexes)
sample_groups=sample_info$group[indexes]
little_DGEList=DGEList(counts[,indexes],
                       group = sample_groups,
                       remove.zeros = TRUE)

# make a design matrix that indicates which samples
# belong to which groups
design=model.matrix(~0+group,data=little_DGEList$samples)
colnames(design)=levels(little_DGEList$samples$group)

# estimate variance parameters needed to fit a 
# model of gene expression
little_DGEList = estimateDisp(little_DGEList,design) 

# fit a generalized linear model to the data
fit = glmFit(little_DGEList, design)

# make a contrast matrix to run a statistical test
# comparing late to early seed development
comparison=paste(group2_name,"-",group1_name)
contrast=makeContrasts(comparison,levels=design)

# run the test; only report results with log fold-change
# bigger than a cutoff
log_foldchange=2
lrt=glmTreat(fit,contrast=contrast,lfc=log_foldchange)

# save results to a variable
results=lrt$table

# add a column with adjusted p value to deal with 
# multiple hypothesis testing problem
# many methods are available - using Bonferroni here,
# the most conservative
results$p=p.adjust(results$PValue,method="bonferroni")

# add a column with gene name
results$gene=rownames(results)

# groom results - keeping the most significant genes
p_threshold=0.0001
to_keep=results$p<p_threshold
results=results[to_keep,c('gene','logFC','p')]

# combine annotations with DE results
results=merge(results,annotations,by.x = "gene",by.y="gene")

# to sanity check results, add columns with
# average expression data
# fpm - fragments per million
fpm=cpm(counts)
# make a new data frame with average normalized counts
group1_ave=rowMeans(fpm[,grep(group1_name,colnames(fpm))])
group2_ave=rowMeans(fpm[,grep(group2_name,colnames(fpm))])
aves=data.frame(gene=row.names(fpm),
                group1=group1_ave,
                group2=group2_ave)
names(aves)[2:3]=c(group1_name,group2_name)

# merge the averages data frame with results
results=merge(results,aves,by.x="gene",by.y="gene")

# order by log fold-change
o=order(results$logFC,decreasing = TRUE)
results = results[o,]

# save result to a file
results_filename=paste0(group1_name,"to",group2_name,".txt")
write.table(results,file=results_filename,quote=FALSE,
            sep="\t",row.names = FALSE)


##### Explore results ######

# view results - select in the Environment tab
# page up and down to see lists of DE genes
# or keyword search

# an example - drought-induced 21
g="Csa12g053650"

# look at its expression in all the samples
fpm[g,]

# view a barplot, color-coded by sample type
barplot(fpm[g,],beside=T,
        main=paste(g,"Expression Profile"),
        col=sample_colors,las=2,ylab="FPM")

# You try it! Pick two samples to compare. How many
# DE genes? 

# hint: replace group1_name and group2_name with 
# different samples





